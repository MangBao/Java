public class PhuThuocHam {
    String veTrai, vePhai;

    public PhuThuocHam(String veTrai, String vePhai) {
        this.veTrai = veTrai;
        this.vePhai = vePhai;
    }    
}